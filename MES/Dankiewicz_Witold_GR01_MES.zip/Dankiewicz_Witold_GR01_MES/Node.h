#pragma once
#ifndef _Node_H
struct Node {
	int id; 
	double x, y; 
	int BC;
	Node();
};
#define _Node_H
#endif