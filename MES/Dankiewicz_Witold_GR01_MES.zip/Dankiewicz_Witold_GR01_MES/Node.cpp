#include"Node.h"
Node::Node() {
	id = 0;
	x = 0;
	y = 0;
	BC = 0;
}